# Notification Design Skill

Quick reference for all notification IDs, triggers, recipients, and channels.

---

## Notification ID Reference

| ID | Section | Type | Recipient | Channel | Trigger |
|----|---------|------|-----------|---------|---------|
| CFG-001 | Setup | 🟠 Action | Admin | In-App | No Org Units on first login |
| CFG-007 | Setup | 🔵 Info | Admin | In-App | All 5 pre-requisites confirmed |
| CFG-008 | Setup | 🟠 Action | Admin | In-App | Scoring formula change with live risks |
| ID-001 | Identification | 🔵 Info | Risk Owner | In-App + Email | External signal affectsYou = true |
| ID-002 | Identification | 🟠 Action | Risk Owner | In-App | Risk proposal from signal |
| ID-003 | Identification | 🔵 Info | Current user | In-App Inline | Duplicate detected (10k browse) |
| ID-004 | Identification | 🔵 Info | Current user | In-App Inline | Risk created with completeness gaps |
| ID-010 | Import | 🔴 Alert | Admin | In-App + Email | Post-import record count discrepancy |
| ID-011 | Import | 🔵 Info | Admin | In-App | Import completeness scan complete |
| ID-020 | Manual | 🔵 Info | Current user | In-App Inline | Duplicate detected (typing) |
| ID-030 | Library | 🔵 Info | Risk Manager | In-App (daily digest) | Orphaned risks found |
| ID-031 | Library | 🔵 Info | Risk Manager | In-App (Watching) | Uncontrolled risks found |
| ASS-001 | Assessment | 🟠 Action | Risk Owner | In-App | Assessment queue ready |
| ASS-002 | Assessment | 🟠 Action | Risk Owner | In-App | Assessor recommendations ready |
| ASS-010 | Assessment | 🟠 Action | Assessor | Email + In-App | Assessment request sent |
| ASS-020 | Assessment | 🔵 Info | Assessors | Email | 50% SLA reminder |
| ASS-021 | Assessment | 🔵 Info | Assessors + Risk Owner | Email + In-App | 75% SLA escalation |
| ASS-022 | Assessment | 🔴 Alert | Risk Owner | In-App + Email | Assessment overdue |
| ASS-030 | Assessment | 🔵 Info | Risk Owner | In-App | Outlier detected |
| ASS-031 | Assessment | 🟠 Action | Risk Owner | In-App | All assessors complete — aggregate |
| ASS-032 | Assessment | 🟠 Action | Risk Owner | In-App | Aggregation result ready |
| ASS-033 | Assessment | 🔵 Info | Risk Owner | In-App + Email | Stale score detected |
| MON-001 | Monitoring | 🔵 Info | Risk Owner | In-App | Baseline score set (first assessment) |
| MON-002 | Monitoring | 🔵 Info | Watching zone | In-App only | Healthy monitoring result |
| MON-003 | Monitoring | 🔴 Alert | Risk Owner | In-App (urgent) + Email | BREACH DETECTED |
| BRE-001 | Breach | 🟠 Action | Risk Owner | In-App (Needs You) | Issue creation plan proposed |
| BRE-002 | Breach | 🔵 Info | Risk Owner | In-App | Issue created and linked |
| BRE-003 | Breach | 🔵 Info | Issue Manager | In-App + Email | Issue assigned |
| BRE-004 | Breach | 🟠 Action | Issue Manager | In-App | Mitigation plan options ready |
| BRE-005 | Breach | 🔴 Alert | Issue Manager + Risk Owner | In-App + Email | No mitigation plan after 5 days |
| BRE-006 | Breach | 🔴 Alert | Issue Manager + Risk Owner | In-App + Email | Actions past SLA |
| BRE-007 | Breach | 🔵 Info | Risk Owner | In-App + Email | Actions complete, re-assess? |
| BRE-008 | Breach | 🟠 Action | Risk Owner | In-App | Re-assessment proposed |
| PMT-001 | Post-mitigation | 🔵 Info | Risk Owner | In-App + Email | Mitigation successful |
| PMT-002 | Post-mitigation | 🟠 Action | Risk Owner | In-App | Graduate to Control proposed |
| PMT-003 | Post-mitigation | 🔵 Info | Risk Owner + Control Owner | In-App | Control created |
| PMT-004 | Post-mitigation | 🔴 Alert | Risk Owner | In-App + Email | Score still breached post-mitigation |
| PMT-005 | Post-mitigation | 🔵 Info | Risk Owner | In-App | Close originating Issue |
| CTL-001 | Control | 🟠 Action | Assessor | Email + In-App | Scheduled control assessment due |
| CTL-003 | Control | 🔴 Alert | Risk Owner (all affected) | In-App + Email | Control failure — CTRL-6 triggered |
| CTL-004 | Control | 🟠 Action | Risk Owner | In-App | Re-assessment proposed per affected risk |
| CTL-005 | Control | 🔵 Info | Risk Owner | In-App | Assessment paused — breach priority |
| REP-001 | Reporting | 🔵 Info | Risk Manager | In-App + Email | Completeness check — 7 days to deadline |
| REP-002 | Reporting | 🟠 Action | Risk Owner | Email + In-App | Chase: missing data before deadline |
| REP-003 | Reporting | 🔵 Info | Risk Owner's manager | Email | Escalation: owner unresponsive |
| REP-004 | Reporting | 🟠 Action | Risk Manager | In-App + Email | Report draft ready for approval |
| REP-006 | Reporting | 🔵 Info | Risk Manager | In-App | Report published successfully |
| REP-007 | Reporting | 🔴 Alert | Admin | In-App + Email | AI Reporting pipeline delivery failed |

---

## Suppression Rules

1. **Max 3 reminders per open item** — after 3 T2 reminders, escalate to manager
2. **Daily digest for library scans** — batch ID-030, ID-031 into one daily message
3. **MON-002 is Watching zone only** — no email for healthy results unless opted in
4. **CTRL-6 consolidation** — one HandoffCard per control failure, listing all affected risks
5. **No duplicates** — if same notification already open in Needs You, do not re-fire
