# Human Interaction Skill

Defines HITL touchpoint types, plan-first protocol, HandoffCard format, and approval gate mechanics for Risk Agent.

---

## HITL Touchpoint Types

| Type | When to use | Human receives | Required response |
|------|-------------|----------------|-------------------|
| **approval_gate** | Before any write with significant consequences | Full plan with before/after state | approve / modify / reject |
| **review_point** | Agent output benefits from human judgment before proceeding | Summary + recommendations | approve / request_changes / dismiss |
| **decision_point** | Next path depends on human professional judgment | Options with implications | select one action |
| **input_request** | Agent needs information only human has | Question with context | free text or selection |
| **notification** | Informing human of completed agent action (T2) | Summary of what happened | no response required |

---

## Plan-First Protocol (T3 Approval Gates)

Every T3 action must present a plan in this format before executing:

```
**[Type]: [Touchpoint Name]**

What I understood:
[Plain language summary of what triggered this]

What I propose to do:
Step 1: [action] → affects [object_id]: [before] → [after]
Step 2: [action] → affects [object_id]: [before] → [after]
...

What I will NOT do:
[Explicitly state what the agent is NOT doing in this proposal]

Reversibility:
[Can this be undone? How? Within what timeframe?]

Confidence: [0–100]%

**[approve] / [modify] / [reject]**
```

---

## Target Role Taxonomy

| Role ID | Who | When assigned |
|---------|-----|---------------|
| `risk_owner` | Owner of the affected risk | Monitoring, breach, identification tasks |
| `admin` | Risk Manager or System Admin | Configuration, report approval, escalations |
| `assessor` | Person assigned to complete an assessment | Assessment requests |
| `issue_manager` | Person assigned to manage an issue | Breach response, mitigation |
| `control_owner` | Owner of the affected control | Control assessment tasks |

**Fallback rule:** If the designated role holder cannot be resolved (user not found, deactivated), escalate to `admin`. Never silently proceed without the right person.

---

## Feedback Loop Rules

- On `request_changes` or `modify`: re-spawn agent with that action. Agent revises and re-presents the **same contract_id**.
- After **3 revision cycles** on the same contract: agent must escalate with a recommendation rather than looping again. Message: "I've presented this [N] times. Here's my recommendation: [X]. Please decide or I'll need to stop."
- On `reject`: log to AuditLog, do not retry. The human has explicitly stopped this action.

---

## Notification Presentation Format

For T2 notifications (informational, no approval needed):

```
🔵 [Notification ID] — [Title]

[1–2 sentence summary of what happened or what was found]

Affected: [object_id] — [object_name]
[Optional: list of specific items if multiple]

[action_link if applicable, e.g., "View Risk" or "Apply Score"]
```

For 🔴 Alerts (immediate attention):

```
🔴 ALERT — [Title]

[Clear statement of what has occurred and why it matters]

Risk: [risk_name] ([risk_id])
Score change: [before] → [after]
Action required: [specific instruction]

[Primary action button]
```
