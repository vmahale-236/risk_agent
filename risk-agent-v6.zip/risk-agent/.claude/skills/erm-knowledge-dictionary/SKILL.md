# ERM Knowledge Dictionary

This skill gives the agent deep domain knowledge of Enterprise Risk Management concepts. When the agent encounters a new custom attribute, workflow status, field name, relationship type, or any other customisation, it uses this dictionary to:

1. **Identify** what the custom element likely represents based on name semantics and context
2. **Confirm** its interpretation with the human before using it
3. **Ask** the human for clarification if it cannot confidently match the element to a known concept

---

## How to Use This Dictionary

When a new custom element is detected (via schema drift scan or direct observation):

```
Step 1: Tokenise the element name (split on _ / - / camelCase)
Step 2: Match tokens against dictionary entries below
Step 3: Identify the most likely concept(s) it represents
Step 4: Check context: what object type does it belong to? What are other fields on the object?
Step 5: Form a confident interpretation OR identify it as ambiguous

If confident (match score > 0.7):
  → Surface to Admin: "I believe [field_name] is [concept]. Is this correct?
    If yes, I'll use it for [agent_behaviour]. If not, please tell me what it does."

If ambiguous (match score 0.4–0.7):
  → Surface to Admin: "I found a new field [field_name] that could be [concept A] or [concept B].
    Which is it, and how should I use it?"

If no match (score < 0.4):
  → Surface to Admin: "I found a new field [field_name] that I don't recognise.
    What does it represent, and should I use it for any agent behaviour?"
```

---

## Part 1 — Risk Concepts

### 1.1 Risk Scoring and Measurement

**Inherent Risk / Gross Risk / Pre-control Risk**
The level of risk before any controls, mitigations, or treatments are applied. Represents the raw exposure if nothing is done.
- Common field names: `inherent_risk`, `inherent_score`, `gross_risk`, `gross_score`, `pre_control_risk`, `raw_risk`, `pre_mitigation_risk`, `unmitigated_risk`, `inherent_rating`
- Agent use: This is the baseline. Monitoring comparison threshold in baseline_only mode.
- Typically composed of: Inherent Likelihood × Inherent Impact

**Residual Risk / Net Risk / Post-control Risk**
The level of risk remaining after controls and mitigations are applied. What the organisation actually faces.
- Common field names: `residual_risk`, `residual_score`, `net_risk`, `net_score`, `post_control_risk`, `current_risk`, `mitigated_risk`, `residual_rating`, `controlled_risk`
- Agent use: Compared against threshold (inherent, appetite, tolerance) to determine breach.

**Target Risk / Desired Risk**
The risk level the organisation aspires to reach after implementing a risk response plan.
- Common field names: `target_risk`, `target_score`, `desired_risk`, `aspired_risk`, `objective_risk_level`, `risk_objective`
- Agent use: Can serve as monitoring threshold in target_score mode. Agent should ask if this should replace inherent as comparison baseline.

**Likelihood / Probability / Frequency**
How likely or frequent a risk event is to occur. One axis of the risk matrix.
- Common field names: `likelihood`, `probability`, `frequency`, `occurrence_likelihood`, `chance`, `likelihood_score`, `likelihood_rating`, `probability_score`, `event_probability`
- Scale types: Qualitative (Rare/Unlikely/Possible/Likely/Almost Certain), Quantitative (1–5), or percentage-based
- Applies to: Both inherent and residual assessments; also used in KRI thresholds

**Impact / Consequence / Severity**
The severity of harm if a risk event occurs. Second axis of the risk matrix.
- Common field names: `impact`, `consequence`, `severity`, `impact_score`, `impact_rating`, `consequence_level`, `harm_level`, `magnitude`
- Dimensions impact can cover: Financial, Reputational, Regulatory, Operational, Strategic
- Agent use: Combined with likelihood to produce composite risk score

**Composite / Overall Risk Score**
The combined score derived from likelihood × impact (or other formula). Used for monitoring and heatmap positioning.
- Common field names: `risk_score`, `overall_score`, `composite_score`, `risk_rating`, `total_score`, `risk_level`, `combined_score`, `risk_exposure`

**Risk Velocity**
How quickly a risk can move from occurrence to impact. High velocity risks provide less time to respond.
- Common field names: `velocity`, `risk_velocity`, `speed_of_onset`, `time_to_impact`, `escalation_speed`
- Agent use: If this field exists, agent should consider it in prioritisation scoring for assessments.

---

### 1.2 Risk Appetite and Tolerance

**Risk Appetite**
The amount and type of risk an organisation is willing to accept in pursuit of its objectives. A strategic-level statement.
- Common field names: `risk_appetite`, `appetite`, `appetite_level`, `risk_appetite_level`, `appetite_score`, `appetite_threshold`, `appetite_rating`, `strategic_appetite`
- Nature: Usually set at category or org-unit level; applied to individual risks
- Agent use: In appetite_threshold mode, this is the monitoring comparison threshold. Residual > Appetite = breach.

**Risk Tolerance**
The acceptable deviation from risk appetite. The boundary beyond which the organisation will not operate. More specific than appetite.
- Common field names: `risk_tolerance`, `tolerance`, `tolerance_level`, `tolerance_threshold`, `tolerance_score`, `maximum_tolerance`, `outer_limit`
- Relationship to appetite: Tolerance is typically higher than appetite. Appetite = where we want to be. Tolerance = where we absolutely cannot exceed.
- Agent use: In tiered_appetite_tolerance mode, residual > tolerance = red breach (hard breach); residual > appetite = amber warning.

**Risk Capacity**
The maximum amount of risk an organisation can absorb before its existence or objectives are threatened. The absolute ceiling.
- Common field names: `risk_capacity`, `maximum_exposure`, `maximum_risk`, `capacity`, `risk_ceiling`, `absolute_limit`
- Agent use: If this exists alongside appetite and tolerance, agent should ask Admin to define the monitoring rule hierarchy.

**Risk Acceptance Level / Acceptance Threshold**
The level at which management formally accepts a risk without further mitigation.
- Common field names: `acceptance_level`, `acceptance_threshold`, `risk_acceptance_threshold`, `tolerable_risk`
- Agent use: May indicate this customer uses formal risk acceptance as a first-class workflow step. If field exists on Risk object, agent should surface in ops.issue_plan as an option.

---

### 1.3 Risk Categorisation and Classification

**Risk Category / Domain / Type**
High-level classification of risk. Used for grouping, reporting, and appetite statements.
- Common field names: `category`, `risk_category`, `risk_type`, `risk_domain`, `risk_class`, `risk_classification`, `risk_area`, `risk_family`
- Common categories: Strategic, Operational, Financial, Compliance/Regulatory, Technology/IT, Reputational, Environmental, Third-Party
- Agent use: Used for matching assessors, monitoring grouping, and reporting sections.

**Risk Sub-Category / Sub-Type**
More granular classification within a category.
- Common field names: `sub_category`, `risk_sub_category`, `sub_type`, `sub_domain`, `risk_subcategory`

**Risk Theme**
An emerging or cross-cutting risk topic that spans multiple categories.
- Common field names: `theme`, `risk_theme`, `emerging_risk`, `horizontal_risk`

**Risk Cause / Source / Driver**
What gives rise to the risk. The root factor.
- Common field names: `cause`, `risk_cause`, `source`, `risk_source`, `driver`, `risk_driver`, `root_cause`, `trigger`
- Bow-tie context: The left side of a bow-tie diagram. Multiple causes can lead to one risk event.

**Risk Event / Hazard**
The specific occurrence that could happen. The risk realisation.
- Common field names: `risk_event`, `event`, `hazard`, `risk_scenario`, `scenario`

**Risk Consequence / Effect / Impact Description**
What happens if the risk event occurs. The outcome.
- Common field names: `consequence`, `effect`, `impact_description`, `risk_impact`, `what_if`, `outcome`
- Bow-tie context: The right side of a bow-tie diagram. Multiple consequences can flow from one event.

---

### 1.4 Risk Treatment and Response

**Risk Response / Treatment Strategy**
How the organisation decides to deal with the risk.
- Common field names: `treatment`, `response`, `risk_response`, `treatment_strategy`, `risk_treatment`, `response_strategy`
- Standard options: Accept / Tolerate / Treat (Mitigate) / Transfer / Terminate (Avoid)
- Also seen as: Accept/Reduce/Share/Avoid; Treat/Tolerate/Transfer/Terminate

**Mitigation Plan / Treatment Plan / Action Plan**
Specific actions to reduce the risk to an acceptable level.
- Common field names: `mitigation_plan`, `treatment_plan`, `action_plan`, `risk_action_plan`, `remediation_plan`, `risk_mitigation`

**Residual Risk After Treatment**
The expected risk level after planned mitigations are fully implemented.
- Common field names: `projected_residual`, `expected_residual`, `post_treatment_risk`, `target_residual`, `anticipated_residual`

---

### 1.5 Risk Status and Lifecycle

**Risk Status**
Where in the management lifecycle the risk currently sits.
- Common field names: `status`, `risk_status`, `lifecycle_status`, `workflow_status`, `stage`, `phase`
- Common values: Draft / Identification / Analysis / Assessment / Treatment / Review / Monitoring / Closed / Archived / Accepted
- Agent use: The Configuration Profile terminal_statuses should be configured from this field's closed/inactive values.

**Review Date / Assessment Due Date**
When the risk is next due for review or formal assessment.
- Common field names: `review_date`, `next_review`, `assessment_due_date`, `next_assessment`, `review_due`, `reassessment_date`, `scheduled_review`, `due_date`

**Last Reviewed / Last Assessed**
When the risk was last formally reviewed or scored.
- Common field names: `last_reviewed`, `last_assessed`, `last_assessment_date`, `last_review_date`, `last_scored`, `review_completed`

**Open Date / Identified Date**
When the risk was first identified and entered into the register.
- Common field names: `open_date`, `identified_date`, `created_date`, `registration_date`, `risk_open_date`, `date_identified`

**Close Date / Retired Date**
When the risk was formally closed or retired from active monitoring.
- Common field names: `close_date`, `closed_date`, `retired_date`, `archived_date`, `resolution_date`

---

## Part 2 — Control Concepts

### 2.1 Control Classification

**Control Category**
Whether the control prevents a risk event or detects it after it occurs.
- Common values and synonyms:
  - **Preventive / Prevention**: Stops the risk event from occurring. Acts before the event. Examples: access controls, segregation of duties, authorisation limits.
  - **Detective / Detection**: Identifies that a risk event has occurred or is occurring. Examples: exception reports, reconciliations, audit logs.
  - **Corrective / Remediation**: Reduces the impact after a risk event has occurred. Examples: incident response, backup restoration, insurance claims.
  - **Directive / Instructive**: Guides or mandates behaviour. Examples: policies, procedures, training.
  - **Deterrent**: Discourages risk behaviour. Examples: disciplinary policies, audit presence.
- Common field names: `control_category`, `control_type_category`, `prevention_detection`, `control_class`

**Control Method / Mechanism**
How the control operates.
- Common values: Manual, Automated, IT-Dependent, Semi-Automated, System-Generated
- Common field names: `control_method`, `automation_level`, `control_mechanism`, `how_operated`

**Control Type / Nature**
The nature of the control from a security/infrastructure perspective.
- Common values: Administrative, Technical, Physical, Operational
- Common field names: `control_type`, `control_nature`, `control_category_type`

**Control Frequency / Periodicity**
How often the control is performed.
- Common values: Continuous, Real-time, Daily, Weekly, Fortnightly, Monthly, Quarterly, Semi-annually, Annually, Ad-hoc
- Common field names: `frequency`, `control_frequency`, `execution_frequency`, `periodicity`, `how_often`

**Key Control / Critical Control**
Designation that this control is critical — its failure would significantly increase risk exposure.
- Common values: Key Control, Non-Key, Critical, Significant, Primary
- Common field names: `control_status`, `key_control`, `is_key_control`, `criticality`, `control_priority`
- Agent use: CTRL-6 HandoffCard escalates to Risk Manager (not just Risk Owner) when failing control is a Key Control.

---

### 2.2 Control Effectiveness

**Design Effectiveness**
Whether the control is designed correctly to address the intended risk. Does the control work as designed on paper?
- Common values: Effective, Partially Effective, Not Effective, Design Gap
- Common field names: `design_effectiveness`, `design_adequacy`, `design_rating`, `control_design`, `design_assessment`

**Operational Effectiveness / Control Effectiveness**
Whether the control is operating as designed in practice. Does it actually work when executed?
- Common values: No Exceptions Noted, Exceptions Noted, Significant Exceptions Noted, Not Tested, Operating Effectively, Operating with Exceptions
- Common field names: `operational_effectiveness`, `control_effectiveness`, `operating_effectiveness`, `test_result`, `execution_effectiveness`

**Overall Control Rating / Control Assessment Result**
A combined view of design + operational effectiveness.
- Common field names: `overall_control_rating`, `control_rating`, `control_assessment_result`, `combined_effectiveness`

**Control Maturity**
How mature or embedded the control is in the organisation's processes.
- Scale: Initial / Managed / Defined / Quantitatively Managed / Optimising (CMM levels)
- Also: 1–5 scale or Low/Medium/High
- Common field names: `maturity`, `control_maturity`, `maturity_level`, `control_maturity_level`

**Mitigation Risk Percentage / Coverage**
The percentage of residual risk exposure this control is estimated to reduce.
- Common field names: `mitigation_percentage`, `mitigation_risk_percentage`, `coverage_percentage`, `risk_reduction`, `risk_reduction_pct`

---

### 2.3 Control Ownership

**Control Owner**
The person responsible for ensuring the control is designed, implemented, and operating.
- Common field names: `control_owner`, `owner`, `responsible_person`, `control_accountable`, `control_lead`

**Control Performer / Operator**
The person who actually executes the control. May differ from the owner.
- Common field names: `performer`, `operator`, `control_performer`, `executed_by`, `control_operator`

**Business Owner**
The business stakeholder who owns the process the control sits within.
- Common field names: `business_owner`, `process_owner`, `line_manager`, `business_lead`, `stakeholder`

---

## Part 3 — Assessment Concepts

### 3.1 Assessment Types

**Risk Event Assessment (REA) / Risk Assessment**
A formal evaluation of a risk's likelihood and impact scores. Produces inherent and residual scores.
- Common field names (object): `risk_assessment`, `risk_event_assessment`, `risk_review`, `risk_evaluation`
- Agent: This is the primary driver of the monitoring comparison.

**Control Assessment / Control Test / Control Evaluation**
A formal evaluation of whether a control is designed and operating effectively.
- Common field names (object): `control_assessment`, `control_test`, `control_evaluation`, `control_review`, `test_of_control`
- Agent: Produces design_effectiveness and operational_effectiveness scores. Triggers CTRL-6 if failing.

**RCSA (Risk and Control Self-Assessment)**
A methodology where business owners assess their own risks and controls, rather than having an independent party do it.
- Indicates: The organisation uses a self-assessment methodology. Assessors are likely the same people who own the risks/controls.
- Common field names: `rcsa`, `rcsa_assessment`, `self_assessment`, `csa`

**Combined Assessment**
A single assessment that covers both risk (likelihood/impact) and controls (effectiveness) simultaneously.
- Common field names: `combined_assessment`, `integrated_assessment`, `risk_control_assessment`

**Peer Review / Independent Assessment**
An assessment conducted by someone other than the risk/control owner.
- Common field names: `peer_review`, `independent_assessment`, `second_line_assessment`, `reviewer_assessment`

---

### 3.2 Assessment Scoring Components

**Assessment Score Components**
These sub-fields within an assessment record represent the scored values:
- Inherent Likelihood: `inherent_likelihood`, `gross_likelihood`, `pre_control_likelihood`
- Inherent Impact: `inherent_impact`, `gross_impact`, `pre_control_impact`
- Inherent Score: `inherent_risk_score`, `gross_risk_score`, `inherent_score` (= likelihood × impact)
- Residual Likelihood: `residual_likelihood`, `net_likelihood`, `post_control_likelihood`
- Residual Impact: `residual_impact`, `net_impact`, `post_control_impact`
- Residual Score: `residual_risk_score`, `net_risk_score`, `residual_score`

**Assessment Confidence / Certainty**
How confident the assessor is in their scoring.
- Common field names: `confidence`, `certainty`, `assessment_confidence`, `scoring_confidence`

**Assessment Rationale / Justification**
The reason or evidence behind the scores given.
- Common field names: `rationale`, `justification`, `evidence`, `scoring_rationale`, `reason_for_score`

---

### 3.3 Assessment Aggregation

**Aggregation Method**
How multiple assessors' scores are combined into one final score.
- Methods: Average (mean), Median, Maximum (most conservative), Minimum (most optimistic), Mode, Weighted Average
- Common field names: `aggregation_method`, `combination_method`, `scoring_method`

**Consensus Score / Final Score**
The agreed-upon score after aggregation or consensus review.
- Common field names: `consensus_score`, `final_score`, `agreed_score`, `committee_score`

---

## Part 4 — Governance Concepts

### 4.1 Three Lines of Defence / Three Lines Model

Understanding which line of defence an attribute or role relates to:

**First Line**
Business units and functions that own and manage risks. They operate controls day-to-day.
- Indicators: fields referencing `first_line`, `1LOD`, `business_unit`, `operational_owner`, `line_1`
- Typical roles: Risk Owners, Control Owners, Process Owners, Business Managers

**Second Line**
Risk management and compliance functions that oversee the first line. They set frameworks, provide tools, and challenge.
- Indicators: fields referencing `second_line`, `2LOD`, `risk_function`, `compliance_function`, `risk_management`, `line_2`
- Typical roles: Risk Managers, Chief Risk Officers, Compliance Officers

**Third Line**
Internal audit, which provides independent assurance to the board and senior management.
- Indicators: fields referencing `third_line`, `3LOD`, `internal_audit`, `audit_function`, `line_3`
- Typical roles: Internal Auditors, Audit Managers, Chief Audit Executives

---

### 4.2 Risk Escalation and Reporting

**Risk Escalation**
The process of raising a risk to a higher authority because it exceeds thresholds or requires decisions beyond current authority levels.
- Common field names: `escalation_level`, `escalation_required`, `escalated_to`, `escalation_status`, `escalation_date`

**Reporting Level / Audience**
What level of the organisation this risk is reported to.
- Common field names: `reporting_level`, `report_to`, `board_reportable`, `executive_reportable`, `committee_reportable`

**Risk Committee**
The governance body responsible for oversight of risk management.
- Common field names: `committee`, `risk_committee`, `governing_body`, `oversight_body`

**Risk Register**
The compiled list of all identified risks managed by the organisation.
- This is the object collection. If a customer uses `risk_register` as a prefix for fields, it's likely their register-level metadata.

---

### 4.3 Risk Frameworks and Standards

When custom fields reference these frameworks, the agent should understand their implications:

**COSO ERM (Committee of Sponsoring Organisations)**
The most widely used ERM framework. Defines 5 components: Governance & Culture, Strategy & Objective-Setting, Performance, Review & Revision, Information, Communication & Reporting.
- Field indicators: `coso_`, `erm_framework`, fields mapping to COSO categories

**ISO 31000**
International standard for risk management. Principles-based, not prescriptive. Widely used globally.
- Field indicators: `iso31000_`, fields referencing `principles`, `framework`, `process` in an ISO context

**NIST (National Institute of Standards and Technology)**
US framework primarily used for cybersecurity risk. Five core functions: Identify, Protect, Detect, Respond, Recover.
- Field indicators: `nist_`, cybersecurity-related fields, `identify_protect_detect`

**BCBS 239 / Basel**
Banking and financial services risk data aggregation and reporting standards.
- Field indicators: `bcbs_`, `basel_`, `regulatory_capital`, banking-specific fields

**COBIT**
IT governance framework. Used for IT risk and control alignment.
- Field indicators: `cobit_`, IT governance fields, `it_objective`

**SOX / ICFR**
Sarbanes-Oxley Act financial controls. Requires documented internal controls over financial reporting.
- Field indicators: `sox_`, `icfr_`, `financial_control`, `section_302`, `section_404`

**GDPR / Data Protection**
Data protection regulation. Risks and controls related to personal data processing.
- Field indicators: `gdpr_`, `data_protection_`, `personal_data`, `data_subject`

---

## Part 5 — Key Risk Indicators (KRIs)

**KRI / Key Risk Indicator**
A measurable value that provides early warning that a risk is increasing. Monitored on a regular schedule.
- Common field names: `kri`, `key_risk_indicator`, `indicator`, `risk_indicator`, `kri_name`
- Relationship to risk: One risk can have multiple KRIs. A KRI breach doesn't mean a risk has materialised — it's a leading indicator.

**KRI Value / Current Value**
The most recent measured value of the KRI.
- Common field names: `kri_value`, `current_value`, `latest_value`, `indicator_value`, `measurement`

**KRI Direction**
Whether an increase is good or bad for the risk.
- Values: Up (↑ increase = worse), Down (↓ decrease = worse)
- Common field names: `direction`, `indicator_direction`, `trend_direction`, `kri_direction`

**KRI Thresholds (RAG)**
The boundaries that determine whether the KRI is in a safe, warning, or breached state.
- Green threshold: `green_threshold`, `lower_bound`, `safe_level`, `kri_green`, `amber_start`
- Amber/Warning threshold: `amber_threshold`, `warning_threshold`, `kri_amber`, `alert_level`
- Red/Breach threshold: `red_threshold`, `breach_threshold`, `kri_red`, `critical_level`

**KRI Frequency**
How often the KRI is measured and updated.
- Common field names: `kri_frequency`, `measurement_frequency`, `update_frequency`, `monitoring_frequency`

**KRI Status / RAG Status**
The current colour-coded status of the KRI.
- Common values: Green / Amber / Red, or In Range / Approaching Limit / Breached
- Common field names: `rag_status`, `kri_status`, `status`, `kri_rag`, `indicator_status`

**KRI Owner**
Who is responsible for measuring and reporting the KRI.
- Common field names: `kri_owner`, `indicator_owner`, `measurement_owner`

---

## Part 6 — Issues, Incidents, and Exceptions

### 6.1 Issue Types

**Issue**
A problem identified in the risk or control environment that needs to be addressed. Created in response to a breach, control failure, or audit finding.
- Distinction from Risk: A risk is a potential future event. An issue is something that has been identified and needs resolution now.

**Incident**
An event that has actually occurred and caused harm or near-miss. More severe than an issue.
- Common field names: `incident`, `risk_incident`, `loss_event`, `operational_loss`

**Exception / Policy Exception**
A formal acknowledgement that a policy or standard is not being followed, with management approval.
- Common field names: `exception`, `policy_exception`, `deviation`, `exemption`, `waiver`

**Control Deficiency / Control Gap**
A specific weakness in a control's design or operation.
- Common field names: `deficiency`, `control_deficiency`, `control_gap`, `control_weakness`

**Audit Finding**
An issue identified during an internal or external audit.
- Common field names: `audit_finding`, `finding`, `audit_observation`, `audit_issue`

---

### 6.2 Issue Severity

**Severity / Priority Levels**
Common values and what they mean:
- **Critical**: Immediate threat to the organisation. Requires immediate escalation to senior management.
- **High**: Significant risk exposure. Requires prompt action and escalation.
- **Medium**: Moderate risk exposure. Requires action within normal business processes.
- **Low**: Minor issue. Can be addressed in normal course of business.
- Also seen as: P1/P2/P3/P4, Major/Moderate/Minor, Red/Amber/Green

---

### 6.3 Issue Lifecycle

**Issue Status**
Common values and what they mean in the lifecycle:
- **Draft**: Issue has been identified but not yet formally raised
- **In Review / Open**: Issue has been raised and is being assessed
- **Remediation Planning**: Management is developing an action plan
- **In Remediation**: Actions are being implemented
- **To Be Approved / Awaiting Approval**: Remediation complete, pending sign-off
- **Closed / Resolved**: Issue has been addressed and closed
- **Accepted**: Risk has been formally accepted without remediation
- **Discarded / Voided**: Issue raised in error or no longer relevant

---

## Part 7 — Relationships and Dependencies

### 7.1 Risk-to-Object Relationships

**Risk → Control (mitigates)**
A control that reduces the likelihood or impact of a risk.
- Relationship types: `mitigates`, `controls`, `addresses`, `covers`, `manages`

**Risk → Process (inherent_in)**
The business process within which the risk exists.
- Relationship types: `inherent_in`, `belongs_to_process`, `process_risk`, `associated_process`

**Risk → Objective (threatens)**
The business objective this risk could prevent from being achieved.
- Relationship types: `threatens`, `impacts_objective`, `affects`, `jeopardises`

**Risk → Risk (related_to)**
Two risks that are correlated, cascading, or interdependent.
- Relationship types: `related_to`, `correlated_with`, `leads_to`, `caused_by`, `amplified_by`

**Risk → Regulation (maps_to)**
The regulatory requirement this risk relates to.
- Relationship types: `maps_to`, `regulatory_risk`, `compliance_risk`, `applies_to`

**Risk → Asset**
The asset (system, facility, data) that could be harmed if the risk materialises.
- Relationship types: `threatens_asset`, `asset_risk`, `affects_asset`

---

### 7.2 Dependency Attributes

**Dependency Field**
A field on one object that is computed from or constrained by another object's state.
- Example: A risk's `overall_risk_score` may be a dependency attribute that automatically updates when its assessment scores change.
- Agent use: If a field is marked as a dependency attribute, agent should not attempt to write to it directly — it is system-computed.

**Cascade / Propagation**
When a change to one object automatically triggers changes to related objects.
- Example: CTRL-6 chain is a cascade — control assessment failure cascades to linked risk re-assessment.
- Common field names: `cascade_on_change`, `propagate_to`, `auto_update`

---

## Part 8 — Bow-Tie Analysis

Bow-tie is a risk analysis method that visualises causes (threats), the risk event (top event), and consequences, with controls mapped to each.

**Top Event**
The central risk event in a bow-tie. What happens when the risk materialises.
- Common field names: `top_event`, `risk_event`, `hazard`, `central_event`, `bow_tie_event`

**Threat / Cause (Left Side of Bow-Tie)**
What could lead to the top event occurring. Multiple threats per top event.
- Common field names: `threat`, `cause`, `bow_tie_cause`, `bow_tie_threat`, `left_side`, `threat_source`

**Consequence (Right Side of Bow-Tie)**
What happens after the top event occurs. Multiple consequences per top event.
- Common field names: `consequence`, `bow_tie_consequence`, `right_side`, `outcome`, `impact_pathway`

**Prevention Barrier / Threat Control**
Controls on the left side of the bow-tie that prevent the top event from occurring.
- Common field names: `prevention_barrier`, `threat_barrier`, `preventive_control`, `cause_control`, `left_barrier`

**Recovery Barrier / Consequence Control**
Controls on the right side that limit the impact after the event has occurred.
- Common field names: `recovery_barrier`, `consequence_barrier`, `corrective_control`, `right_barrier`

**Escalation Factor / Degradation Condition**
A condition that makes a barrier less effective.
- Common field names: `escalation_factor`, `degradation_factor`, `barrier_degradation`, `control_degradation`

---

## Part 9 — Organisational Concepts

### 9.1 Organisational Structure

**Org Unit / Business Unit / Department**
Organisational subdivisions that own risks and controls.
- Common field names: `org_unit`, `business_unit`, `department`, `division`, `entity`, `legal_entity`, `region`, `geography`

**Geography / Region / Country**
Location-based organisational segmentation.
- Common field names: `geography`, `region`, `country`, `location`, `jurisdiction`

**Process**
A set of activities that transforms inputs to outputs. Risks exist within processes.
- Common field names: `process`, `business_process`, `process_area`, `process_type`, `activity`

**Objective**
A goal or target the organisation is working towards. Risks threaten objectives.
- Levels: Strategic / Operational / Financial / Compliance
- Common field names: `objective`, `business_objective`, `strategic_objective`, `target`, `goal`

---

### 9.2 Roles and Responsibilities

**Risk Owner / Risk Custodian / Risk Manager (role)**
The person accountable for managing a specific risk.
- Common field names: `owner`, `risk_owner`, `custodian`, `accountable_person`, `responsible_owner`

**Risk Assessor / Assessor**
The person who performs the risk assessment scoring.
- Common field names: `assessor`, `risk_assessor`, `assessment_owner`, `scorer`, `evaluator`

**Control Owner**
The person accountable for a specific control.
- Common field names: `control_owner`, `owner`, `accountable_owner`

**Control Performer / Tester**
The person who executes or tests the control.
- Common field names: `performer`, `tester`, `test_owner`, `execution_owner`, `control_tester`

**Risk Manager (admin role)**
The administrator of the Risk Manager application. Has full system access.
- Distinct from: Risk Owner (who owns individual risks)

**Process Owner**
The person accountable for a business process.
- Common field names: `process_owner`, `process_accountable`, `process_lead`

---

## Part 10 — Quantitative Risk Methods

### 10.1 Financial Quantification

**Expected Loss**
The average loss expected from a risk over a period.
- Common field names: `expected_loss`, `el`, `annual_expected_loss`, `average_loss`
- Calculation: Frequency × Severity

**Potential Loss / Maximum Loss**
The worst-case scenario loss.
- Common field names: `potential_loss`, `maximum_loss`, `worst_case`, `max_exposure`, `plausible_worst_case`

**Loss Event Data**
Historical records of actual losses used to calibrate risk models.
- Common field names: `loss_data`, `historical_loss`, `loss_event`, `loss_history`, `actual_loss`

**Risk Cost / Risk Value**
Monetary valuation of the risk exposure.
- Common field names: `risk_cost`, `risk_value`, `financial_exposure`, `monetary_risk`, `risk_amount`

**FAIR (Factor Analysis of Information Risk)**
Quantitative framework for understanding, measuring, and analysing information risk in financial terms.
- Field indicators: `fair_`, `lef`, `tef`, `cap`, `vulnerability`, `contact_frequency` — these are FAIR-specific terms

**Value at Risk (VaR)**
Statistical measure of the maximum loss expected at a given confidence level.
- Common field names: `var`, `value_at_risk`, `99_var`, `95_var`, `confidence_interval`

---

### 10.2 Scenario Analysis

**Scenario**
A defined narrative describing how a risk could materialise.
- Common field names: `scenario`, `risk_scenario`, `stress_scenario`, `what_if_scenario`

**Stress Test / Scenario Score**
The impact score under a specific extreme scenario.
- Common field names: `stress_score`, `scenario_score`, `stress_test_result`, `scenario_impact`

---

## Part 11 — Third-Party Risk (TPRM)

**Vendor / Third Party / Supplier**
External organisations that the company relies on and that introduce risk.
- Common field names: `vendor`, `third_party`, `supplier`, `contractor`, `service_provider`, `partner`

**Inherent Vendor Risk**
The risk introduced by the vendor before any controls are considered.
- Common field names: `vendor_risk`, `third_party_risk`, `supplier_risk`, `inherent_vendor_risk`

**Due Diligence**
The assessment process for evaluating a third party before engagement.
- Common field names: `due_diligence`, `dd_score`, `vendor_assessment`, `supplier_assessment`

**Contract Risk**
Risks arising from contractual obligations or gaps.
- Common field names: `contract_risk`, `contractual_risk`, `contract_score`, `agreement_risk`

**Concentration Risk**
The risk arising from over-dependence on a single vendor or small number of vendors.
- Common field names: `concentration_risk`, `single_supplier_risk`, `dependency_risk`, `vendor_concentration`

---

## Part 12 — Compliance and Regulatory

**Regulatory Requirement / Obligation**
A specific rule or obligation from a regulator or legislation.
- Common field names: `requirement`, `regulation`, `obligation`, `regulatory_requirement`, `rule`, `provision`, `article`, `clause`

**Compliance Status**
Whether the organisation is meeting the regulatory requirement.
- Common values: Compliant, Partially Compliant, Non-Compliant, Not Applicable, Under Review
- Common field names: `compliance_status`, `compliance_rating`, `compliance_level`, `adherence_status`

**Regulatory Risk**
The risk of non-compliance with laws and regulations.
- Common field names: `regulatory_risk`, `compliance_risk`, `regulatory_exposure`

**Breach / Non-Compliance Event**
An instance where the organisation has failed to meet a regulatory requirement.
- Common field names: `breach`, `non_compliance`, `regulatory_breach`, `compliance_breach`, `violation`

---

## Part 13 — Operational Resilience

**Recovery Time Objective (RTO)**
The maximum acceptable time for restoring a critical process after disruption.
- Common field names: `rto`, `recovery_time_objective`, `max_downtime`, `target_recovery_time`

**Recovery Point Objective (RPO)**
The maximum acceptable data loss measured in time.
- Common field names: `rpo`, `recovery_point_objective`, `max_data_loss`, `data_recovery_point`

**Maximum Tolerable Period of Disruption (MTPD)**
The maximum time a critical business service can be unavailable before causing irreversible harm.
- Common field names: `mtpd`, `max_tolerable_disruption`, `maximum_disruption`, `critical_threshold`

**Business Impact Analysis (BIA)**
Assessment of the impact of disruption to business activities.
- Common field names: `bia`, `business_impact`, `impact_analysis`, `criticality_rating`

**Critical Process / Critical Function**
A process whose disruption would cause severe harm to the organisation.
- Common field names: `critical_process`, `critical_function`, `importance`, `criticality`, `priority_tier`

---

## Unknown Custom Element Protocol

When encountering a field, status, relationship type, or attribute that does not match any concept in this dictionary:

```
Step 1: Determine the object type it belongs to (Risk, Control, Assessment, Issue, etc.)
Step 2: Look at other fields on the same object for context clues
Step 3: Check if the name appears similar to any dictionary entry (fuzzy match)
Step 4: If still unknown — ask the human:

"I found a new custom element I don't recognise:
  Object type: [Risk / Control / etc.]
  Element name: [field_name]
  Element type: [attribute / workflow_status / relationship_type / role]

I searched my risk management knowledge base and couldn't confidently identify what this represents.

Could you tell me:
1. What does [field_name] represent in your risk management process?
2. How is it used? (scoring, categorisation, monitoring, reporting, access control, etc.)
3. Should the agent use it for any monitoring or decision-making logic?

Once you tell me, I'll add it to my knowledge for this organisation and update the
Configuration Profile accordingly."
```

Store the human's answer as an `org_custom_concept`:
```json
{
  "field_name": "custom_field_xyz",
  "object_type": "risk",
  "human_definition": "Text from human explaining what it does",
  "agent_behaviour": "How agent should treat this field",
  "added_by": "USR-010",
  "added_at": "ISO 8601"
}
```

These org_custom_concepts are stored in agent long-term memory and referenced in future encounters with the same field.
