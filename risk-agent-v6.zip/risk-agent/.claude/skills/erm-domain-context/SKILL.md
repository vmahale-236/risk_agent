# ERM Domain Context Skill

Shared domain knowledge for all Risk Agent agents.

---

## User Roles

| Role | Access | Notes |
|------|--------|-------|
| **Admin / Risk Manager** | All risks, all settings, all agent actions | Final escalation target |
| **Risk Owner** | Only risks assigned to them | No Settings access |
| **Assessor** | Only assessments assigned to them | Scoring only |
| **Control Owner** | Only controls assigned to them | |
| **Issue Manager** | Issues assigned to them | Receives assignments from Operations Agent |

**Role enforcement:** Before every agent action, check user role. Never surface Risk Owner A's risks to Risk Owner B.

---

## Archived Risk Rule

**Hard skip: never monitor, flag, or alert on any risk with `workflow_status = "Archived"`.**
This applies to ALL agents and ALL jobs without exception.
Always check `workflow_status` before any processing.

---

## Manual Mode Rule

When `agent_managed = false` on a risk:
- Operations Agent stops monitoring and proposing on that risk
- Assessment Agent still runs on that risk (assessments can still be scheduled)
- All score changes are still logged to AuditLog silently
- Manual mode expires automatically at `manual_mode_duration` — agent resumes

---

## Snooze Rule

When `snooze_until` is set and in the future on a risk:
- Operations Agent does not fire breach alerts
- Score changes are still logged silently
- Assessment schedule monitoring still runs
- Snooze expires automatically — agent resumes breach monitoring

---

## Object Model (Current ERM)

### Risk
- `id`, `name` (required), `reference_id`
- `description` (rich text)
- `category` → links to RiskCategory
- `owner_id` → links to User
- `org_unit_id` → links to OrgUnit
- `workflow_status`: Draft | Identification | Analysis | Assessment | Response | Review | **Archived**
- `inherent_likelihood`, `inherent_impact`, `inherent_risk_score`
- `residual_likelihood`, `residual_impact`, `residual_risk_score`
- `last_assessment_date`, `assessment_due_date`
- `agent_managed`: boolean (default: true) — false when in Manual Mode
- `snooze_until`: date | null
- `snooze_reason`: string | null
- `manual_mode_since`: date | null
- `manual_mode_duration`: string | null
- Custom fields: discovered via `get_object_schema`

### Risk Event Assessment (REA)
- `id`, `name` (required), `parent_risk_id`
- `owner_id` (assessor)
- `workflow_status`: Draft | Assessment | Monitoring (customisable)
- `inherent_likelihood`, `inherent_impact`, `inherent_risk_score`
- `residual_likelihood`, `residual_impact`, `residual_risk_score`
- Custom fields: customer-defined

### Control
- `id`, `name` (required), `reference_id`
- `description` (rich text)
- `owner_id`, `org_unit_id`
- `workflow_status`: Draft | Implementation | Analysis | Assessment | Testing | Approval | Monitoring
- `control_category`: Preventive | Detective
- `control_method`: Operational | IT-based | Manual
- `control_status`: Key Control | Standard | Inactive
- `control_frequency`: Weekly | Fortnightly | Monthly | Quarterly | Semi-annually | Annually
- `control_type`: Administrative | Technical | Physical
- `mitigation_risk_percentage` (numeric)
- Custom fields

### Control Assessment
- `id`, `name`, `parent_control_id`, `owner_id`
- `design_effectiveness`: Effective | Partially Effective | Not Effective
- `control_effectiveness`: No Exceptions Noted | Exceptions Noted | Significant Exceptions Noted | Not Tested
- `workflow_status`: Draft | Assessment | Monitoring

### Issue
- `id`, `title` (required), `description`
- `type`: Issue | Incident | Exception | Control Deficiency | Audit Finding
- `severity`: Low | Medium | High | Critical
- `status`: Draft | In Review | Remediation Planning | In Remediation | To Be Approved | Closed | Discarded
- `owner_id`, `reporter_id`, `approver_id`
- `linked_risk_id`, `linked_control_id`
- `due_date`

### Risk Acceptance
- `id`, `risk_id`, `accepted_by`, `accepted_at`
- `reason`, `accepted_score`, `review_date`
- Created when Risk Owner formally accepts elevated risk instead of creating an Issue

### Action Item
- `id`, `name`, `description`
- `linked_issue_id`
- `owner_id`, `due_date`, `status`
- Created when breach re-fires on a risk that already has an open Issue

### Other Objects
- `OrgUnit`, `User`, `RiskCategory`, `ScoringMatrix`, `TaxonomyCategory`, `KRI`
- `AuditLogEntry`: full audit trail (see AuditLog Standard below)
- `AgentRule`: autonomy rules / constitution
- `WorkflowApproval`
- `NotificationLog`

---

## Pre-Requisite Setup (5 items, all required before agents can write)

1. **OrgUnit** — organisational hierarchy
2. **Users** — added to DiligentOne and assigned to Org Units
3. **Roles/Permissions** — at least one Admin, one Risk Owner
4. **Risk Categories** — at minimum one category
5. **Scoring Formulas** — at minimum one N×N matrix

Not in current ERM (future state): KRIs, Risk Appetite, Risk Tolerance, Taxonomy.

---

## Autonomy Tiers

| Tier | Behaviour | When to use |
|------|-----------|-------------|
| **T1** | Act silently, log to AuditLog | Monitoring, health checks, reads |
| **T2** | Act then notify | Reminders, flags, assignments |
| **T3** | Propose plan, await approval | Creates, writes, publications |
| **T4** | Permanently forbidden | See list per agent |

**Plan-first protocol (T3):** Every T3 proposal must show: what will happen, which objects are affected, before/after state per field, reversibility statement.

---

## Counter-Check Rule (T3 on_modify path)

When a human modifies an agent proposal, the agent does NOT blindly execute. It validates:

1. Are the human-supplied values internally consistent with the customer's schema?
2. Do the human values contradict the agent's reasoning in a way that could cause harm or confusion?
3. If yes to (2) → show counter-alert explaining the potential issue
4. Human must explicitly confirm the counter-alert before the agent executes
5. Log both: what the agent recommended AND what the human decided AND whether counter-alerts were shown and confirmed

**The human's confirmed decision is always final.** The agent counters to inform, not to block.

---

## Escalation Protocol (after 3 rejections)

When any T3 touchpoint has been rejected 3 times by the target role:

1. Escalate to the next role up:
   - `risk_owner` → escalate to `admin`
   - `admin` → admin is final; present all prior proposals, let admin decide
2. Show all 3 prior proposals with dates and rejection notes
3. Admin options: approve one proposal / modify and create manually / accept risk / take no action
4. Log all prior proposals and final admin decision to AuditLog

---

## AuditLog Standard (all agents)

Every agent action must write to AuditLog:
```json
{
  "actor": "agent | human",
  "agent_name": "string",
  "action": "string",
  "object_type": "string",
  "object_id": "string",
  "agent_recommendation": {},
  "human_decision": "approved_as_is | modified | rejected | accepted_risk | snoozed | manual_mode | escalated | reverted",
  "human_values": {},
  "counter_alerts_shown": [],
  "human_confirmed_counter_alerts": true,
  "timestamp": "ISO 8601"
}
```

This is how the agent remembers human score overrides — by scanning `AuditLogEntry` records where `actor = "human"` and `action = "update"` on risk score fields.

---

## CTRL-6 Chain Business Rule

```
Control Assessment Fails
  → Operations Agent detects via control_score_applied
  → Identifies all linked active risks
  → Surfaces re-assessment recommendation per risk (T3)
  → Human approves per risk
  → Assessment Agent runs new cycle
  → New score compared (Operations Agent)
  → If breach → Issue or Action Item (if Issue exists)
```

**Empty score submissions do not trigger CTRL-6.** Assessment Agent validates scores before firing events.

---

## First vs. Re-Assessment Rule

Agent determines this from the Risk Details page state:
- `inherent_risk_score` was null/empty before this assessment → **first** → baseline only, no breach check
- `inherent_risk_score` was already populated → **subsequent** → comparison fires

Human manual score changes are treated as **subsequent** assessments.

---

## MCP Server Availability Rule (all agents)

Before every job:
1. Ping MCP Server
2. If unreachable → emit SYS-001, enter standby, retry every 5 minutes
3. Never attempt read/write operations while server is unreachable
4. On recovery → emit SYS-002, resume queued operations

---

## Notification Batching Rule

All daily scan results (library health, stale scores, schedule monitoring) must be batched into a single daily digest per recipient. Never send one notification per risk. The platform's notification digest functionality handles delivery consolidation.

---

## T4 Permanently Forbidden (all agents)

- Delete any risk record
- Delete any control record
- Override Risk Appetite or Risk Tolerance definitions
- Assign regulatory classification without human confirmation
- Send communications to external parties without explicit human approval
- Modify scoring formula without impact analysis
- Disable or bypass the AuditLog
- Grant Admin-level access to Risk Owners
- Fire `score_applied` or `control_score_applied` with empty score values
