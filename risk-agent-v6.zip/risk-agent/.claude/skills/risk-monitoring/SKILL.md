# Risk Monitoring Skill

Score comparison logic, breach detection, human override detection, CTRL-6 matrix, and mitigation loop.

---

## Score Comparison Logic

**Never compare scores as strings. Always use ordinal ranking.**

```
Step 1: Load scoring_scale (from score_applied event or get_object_schema)
Step 2: Build ordinal map: { "Very Low":1, "Low":2, "Medium":3, "High":4, "Very High":5 }
        (or customer's equivalent labels)
Step 3: residual_rank = map[residual_risk_score]
        inherent_rank = map[inherent_risk_score]
Step 4:
  residual_rank > inherent_rank → BREACH
  residual_rank = inherent_rank → NO CHANGE (treat as healthy, log)
  residual_rank < inherent_rank → HEALTHY
```

Customer scales vary. Some use 1–5 numeric, some use word labels, some custom. The ranking logic is always the same.

---

## Human Score Override Detection

Operations Agent scans AuditLog for human-made score changes:

```
Query: AuditLogEntry where:
  actor = "human"
  AND action = "update"
  AND object_type = "risk"
  AND changed_fields contains inherent_risk_score OR residual_risk_score

For each match:
  - Capture: previous_value, new_value, changed_by, changed_at
  - Use new_value as current authoritative score
  - assessment_cycle = "subsequent"
  - Proceed with monitoring comparison using human-set values
  - Log: "Human score override detected: [field] [previous] → [new] by [user] at [time]"
```

**The human's score is always the authoritative value.** The agent never overrides it — it monitors against it.

---

## First vs. Re-Assessment Detection

```
Before comparing any scores:

1. Read risk record: get_object(type=risk, id=risk_id)
2. Check: was inherent_risk_score null/empty BEFORE this write?
   - risk.last_assessment_date is null → first assessment
   - risk.inherent_risk_score was null → first assessment
3. "first" → baseline, no comparison, no breach check
4. "subsequent" → run comparison
```

Never fire breach on a first assessment. This is the most common false positive.

---

## CTRL-6 Failure Matrix

```
| Design Effectiveness | Control Effectiveness          | Verdict  | Action                |
|----------------------|-------------------------------|----------|-----------------------|
| Effective            | No Exceptions Noted            | HEALTHY  | Log T1                |
| Effective            | Exceptions Noted               | PARTIAL  | Flag T2 to Risk Owner |
| Partially Effective  | No Exceptions Noted            | DEGRADED | Flag T2 to Risk Owner |
| Partially Effective  | Exceptions Noted               | FAILING  | CTRL-6 chain          |
| Partially Effective  | Significant Exceptions Noted   | FAILING  | CTRL-6 chain          |
| Not Effective        | No Exceptions Noted            | FAILING  | CTRL-6 chain          |
| Not Effective        | Exceptions Noted               | FAILING  | CTRL-6 chain          |
| Not Effective        | Significant Exceptions Noted   | CRITICAL | CTRL-6 chain (urgent) |
| Any                  | Not Tested                     | UNKNOWN  | Flag as incomplete    |
```

CTRL-6 triggers for: FAILING and CRITICAL only.
PARTIAL and DEGRADED: flag to Risk Owner, do not trigger full chain.
UNKNOWN (Not Tested): flag as incomplete assessment, do not trigger chain.

**Pre-condition:** Both fields must be non-null and non-"Not Tested". If either is empty, emit incomplete assessment flag and stop — do not evaluate the matrix.

---

## Assessment Schedule Monitoring Logic

```
For each active risk:
  If assessment_due_date < today → overdue
  If last_assessment_date + staleness_threshold < today → stale
  If assessment_due_date is null → unscheduled

Staleness threshold default: 180 days (configurable by Admin)
```

Overdue and stale notifications go to the Risk Owner's daily digest — not individual alerts.
Include: risk name, due date (or last assessed date), days overdue/stale.

---

## Breach Loop State Machine

```
BREACH_DETECTED
  → Check: open Issue on this risk?
    No → ISSUE_CREATED (T3 approval) → ISSUE_ASSIGNED
    Yes → ACTION_ITEM_ADDED to existing issue (T3 approval)
        ↓
MITIGATION_PLAN_DEFINED (Issue Manager)
        ↓
ACTIONS_COMPLETE (Issue Manager)
        ↓
REASSESSMENT_TRIGGERED (T3 approval by Risk Owner → Assessment Agent)
        ↓
SCORE_COMPARED (Operations Agent T1)
        ↓
[improved] → CONTROL_CREATED (T3) → ISSUE_CLOSED → HEALTHY
[still breached] → ACTION_ITEM_ADDED to existing issue (loop continues)
[accepted] → RISK_ACCEPTED (formal record created) → monitoring continues
```

SLA defaults (configurable):
- ISSUE_CREATED → MITIGATION_PLAN_DEFINED: 5 business days
- ACTIONS_COMPLETE → REASSESSMENT_TRIGGERED: 5 business days

---

## Staleness Detection

Risk score stale when:
- `last_assessment_date` > staleness_threshold days ago (default 180)
- OR `residual_risk_score` is null while open Issues exist

Control score stale when:
- `last_assessment_date` > `control_frequency` + 30 days
